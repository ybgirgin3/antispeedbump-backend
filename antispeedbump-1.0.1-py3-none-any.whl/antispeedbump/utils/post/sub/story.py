def _story() -> bool:
    # _story_url = https://www.instagram.com/api/v1/feed/reels_tray/
    api = "https://www.instagram.com/api/v1/web/create/configure_to_story/"

    return False
